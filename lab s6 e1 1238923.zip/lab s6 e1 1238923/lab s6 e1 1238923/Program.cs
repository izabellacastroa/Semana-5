﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ingresar mes del año (número del 1 al 12):");
        int mes = Convert.ToInt32(Console.ReadLine());

        int numeroDias;

        switch (mes)
        {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                numeroDias = 31;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                numeroDias = 30;
                break;
            case 2:
                Console.WriteLine("Ingresar el año:");
                int año = Convert.ToInt32(Console.ReadLine());

                if ((año % 4 == 0 && año % 100 != 0) || año % 400 == 0)
                {
                    numeroDias = 29;
                }
                else
                {
                    numeroDias = 28;
                }
                break;
            default:
                Console.WriteLine("Número inválido.");
                return;
        }

        Console.WriteLine("El mes {0} tiene {1} días.", mes, numeroDias);
    }
}


